import java.util.ArrayList;

public class Player //player object (superclass for human, rand, and smart)
{
    public int num; //player number
    public int type; //player type

    public Player(int num,int type) //initializes player object
    {
        this.num = num;
        this.type = type;
    }



}
