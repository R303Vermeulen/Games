public class Circle  //Circle obect for background
{
    public float x; //x position
    public float y; //y position
    public float r; //radius
    public float c1; //first color
    public float c2; //first color

    public Circle(float x, float y, float r, float c1, float c2) //initializes each object
    {
        this.x = x;
        this.y = y;
        this.r = r;
        this.c1 = c1;
        this.c2 = c2;
    }

}
